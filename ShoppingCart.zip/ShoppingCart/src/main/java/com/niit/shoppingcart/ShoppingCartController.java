package com.niit.shoppingcart;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/niit")
public class ShoppingCartController {

	 @RequestMapping("/debdeep")
		public String shoppingcart()
		{
		  return "shoppingcart";
		}
	
	 @RequestMapping("/home")
		public String home()
		{
		  return "website";
		}
	 
}
